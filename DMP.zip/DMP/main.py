"""Command-line interface for the DMP planarity checker."""

from dmp import is_planar_dmp


def read_graph():
    print("DMP Planarity Checker")
    print("---------------------")
    print("Enter the number of vertices and edges.")

    vertex_count = int(input("Number of vertices: "))
    edge_count = int(input("Number of edges: "))

    vertices = list(range(vertex_count))
    edges = []

    print("\nEnter each edge as two vertex numbers (0 to n-1).")
    for i in range(edge_count):
        u, v = map(int, input(f"Edge {i + 1}: ").split())
        edges.append((u, v))

    return vertices, edges


def main():
    vertices, edges = read_graph()

    try:
        result = is_planar_dmp(vertices, edges)
    except ValueError as error:
        print(f"\nInput error: {error}")
        return

    print("\n========== RESULT ==========")
    if result["is_planar"]:
        print("The graph is PLANAR.")
        print("\nPlanar embedding faces (one list per block):")
        for block_info in result["faces"]:
            print(f"Block {block_info['block']}:")
            for face_number, face in enumerate(block_info["faces"], start=1):
                print(f"  Face {face_number}: {face}")
    else:
        print("The graph is NON-PLANAR.")
        print("\nReason: at least one remaining fragment has no admissible face.")
        for block_info in result["blocks"]:
            if not block_info["is_planar"]:
                print(f"Non-planar block: {block_info['vertices']}")
                print("DMP steps:")
                for step in block_info["steps"]:
                    print(f"  {step}")


if __name__ == "__main__":
    main()
