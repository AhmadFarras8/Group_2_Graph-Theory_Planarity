"""Unit tests for the DMP planarity implementation."""


import unittest

from dmp import is_planar_dmp


def complete_graph(n):

    """Return the vertices and edges of the complete graph K_n."""

    vertices = list(range(n))
    edges = [
        (u, v)
        for u in range(n)
        for v in range(u + 1, n)
    ]
    return vertices, edges


class TestDMPPlanarity(unittest.TestCase):

    """Regression tests for planar and non-planar graph examples."""

    def assert_planarity(self, vertices, edges, expected):
        result = is_planar_dmp(vertices, edges)
        self.assertIn("is_planar", result)
        self.assertIs(result["is_planar"], expected)

    def test_triangle_is_planar(self):
        self.assert_planarity(
            [0, 1, 2], [(0, 1), (1, 2), (2, 0)], True
        )

    def test_tree_is_planar(self):
        self.assert_planarity(
            [0, 1, 2, 3], [(0, 1), (1, 2), (1, 3)], True
        )

    def test_cycle_c5_is_planar(self):
        self.assert_planarity(
            list(range(5)),
            [(0, 1), (1, 2), (2, 3), (3, 4), (4, 0)],
            True,
        )

    def test_k4_is_planar(self):
        vertices, edges = complete_graph(4)
        self.assert_planarity(vertices, edges, True)

    def test_k5_is_non_planar(self):
        vertices, edges = complete_graph(5)
        self.assert_planarity(vertices, edges, False)

    def test_k33_is_non_planar(self):
        edges = [
            (u, v)
            for u in range(3)
            for v in range(3, 6)
        ]
        self.assert_planarity(list(range(6)), edges, False)

    def test_disconnected_graph_is_planar(self):
        self.assert_planarity([0, 1, 2, 3], [(0, 1), (2, 3)], True)

    def test_two_triangles_sharing_articulation_vertex_are_planar(self):
        edges = [
            (0, 1), (1, 2), (2, 0),
            (0, 3), (3, 4), (4, 0),
        ]
        self.assert_planarity(list(range(5)), edges, True)

    def test_empty_graph_is_planar(self):
        self.assert_planarity([], [], True)

    def test_isolated_vertices_are_planar(self):
        self.assert_planarity([0, 1, 2, 3], [], True)

    def test_string_vertex_labels_are_supported(self):
        self.assert_planarity(
            ["A", "B", "C"],
            [("A", "B"), ("B", "C"), ("C", "A")],
            True,
        )

    def test_undeclared_vertex_raises_value_error(self):
        with self.assertRaises(ValueError):
            is_planar_dmp([0, 1], [(0, 2)])

    def test_self_loop_raises_value_error(self):
        with self.assertRaises(ValueError):
            is_planar_dmp([0, 1], [(0, 0)])


if __name__ == "__main__":
    unittest.main()
