"""Small regression tests for the DMP implementation."""

from dmp import is_planar_dmp


def complete_graph(n):
    return list(range(n)), [
        (u, v) for u in range(n) for v in range(u + 1, n)
    ]


def test_case(name, vertices, edges, expected):
    result = is_planar_dmp(vertices, edges)
    actual = result["is_planar"]
    status = "PASS" if actual == expected else "FAIL"
    print(f"{status}: {name} -> {'PLANAR' if actual else 'NON-PLANAR'}")
    if actual != expected:
        raise AssertionError(f"{name}: expected {expected}, got {actual}")


if __name__ == "__main__":
    # A tree and a cycle are planar.
    test_case("Tree", [0, 1, 2, 3], [(0, 1), (1, 2), (1, 3)], True)
    test_case("Cycle C5", list(range(5)),
              [(0, 1), (1, 2), (2, 3), (3, 4), (4, 0)], True)

    # K4 is planar; K5 and K3,3 are non-planar.
    v4, e4 = complete_graph(4)
    test_case("K4", v4, e4, True)

    v5, e5 = complete_graph(5)
    test_case("K5", v5, e5, False)

    k33_edges = [
        (u, v) for u in range(3) for v in range(3, 6)
    ]
    test_case("K3,3", list(range(6)), k33_edges, False)

    # Disconnected planar graph.
    test_case("Disconnected graph", [0, 1, 2, 3],
              [(0, 1), (2, 3)], True)

    # Two planar blocks sharing an articulation vertex.
    test_case("Two triangles sharing a vertex", list(range(5)),
              [(0, 1), (1, 2), (2, 0), (0, 3), (3, 4), (4, 0)], True)
