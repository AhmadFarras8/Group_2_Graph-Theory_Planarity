# DMP Planarity Checker (Python)

## Identity

Informatics ITS Graph Theory Class — Group [write your group number]

## Overview

This project implements the Demoucron–Malgrange–Pertuiset (DMP) planarity
testing method for undirected simple graphs.

The implementation incrementally builds a planar embedding. It begins with
a cycle, identifies the remaining fragments (also called bridges), checks
which existing faces can contain each fragment, and inserts a path into an
admissible face. Inserting a path splits one face into two.

If a remaining fragment has no admissible face, the current embedding cannot
be extended and the block is reported as non-planar. The graph is decomposed
into biconnected components so that disconnected graphs and articulation
points can also be handled.

## Files

- `main.py` — command-line input and output.
- `dmp.py` — DMP planarity implementation.
- `sample_input.txt` — sample K5 input.
- `test_dmp.py` — basic regression tests.

## Requirements

- Python 3.8 or newer.
- No third-party Python packages are required.

## How to run

Open a terminal in this directory:

```bash
python main.py
```

Enter the number of vertices, number of edges, and then each edge as two
vertex labels. The command-line interface uses vertices numbered from `0`
to `n-1`.

Example:

```text
Number of vertices: 5
Number of edges: 10
Edge 1: 0 1
Edge 2: 0 2
Edge 3: 0 3
Edge 4: 0 4
Edge 5: 1 2
Edge 6: 1 3
Edge 7: 1 4
Edge 8: 2 3
Edge 9: 2 4
Edge 10: 3 4

========== RESULT ==========
The graph is NON-PLANAR.
```

## Run tests

```bash
python test_dmp.py
```

The tests include a tree, cycle, K4, K5, K3,3, a disconnected graph, and
two triangles sharing an articulation vertex.

## Algorithm outline

1. Build an undirected adjacency-list representation.
2. Decompose the graph into biconnected components using Tarjan's DFS.
3. For each non-trivial block, find an initial cycle.
4. Treat the cycle as the initial embedded subgraph. Its two faces are the
   two sides of the cycle.
5. Find fragments relative to the embedded subgraph:
   - components of vertices not yet embedded, including their edges to
     embedded vertices;
   - unused edges whose endpoints are both already embedded (chords).
6. For each fragment, calculate its admissible faces. A face is admissible
   when its boundary contains every contact vertex of that fragment.
7. Select a fragment with the fewest admissible faces. If it has none, report
   the block as non-planar.
8. Find an alpha-path inside the selected fragment between two contact
   vertices on the chosen admissible face.
9. Insert that path into the face. The face is split into two new faces.
10. Repeat until no fragments remain. If all blocks finish, the graph is
    planar.

## Limitations

- The implementation is intended for undirected simple graphs.
- Self-loops are rejected. Parallel edges should be consolidated before
  input.
- The implementation is educational and prioritizes clarity over optimized
  performance.
- DMP maintains a partial embedding. When multiple admissible faces exist,
  this implementation chooses the first one in its face list; the order can
  affect the resulting embedding and should be tested against the group's
  required examples.

## AI usage disclosure

AI assistance was used to help draft and explain the Python implementation,
organize the project files, and prepare sample tests and documentation.
The group should review, run, understand, and modify the code before
submission, and disclose AI assistance according to the course instructions.
