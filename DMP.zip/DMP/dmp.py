"""
Demoucron-Malgrange-Pertuiset (DMP) planarity testing algorithm.

This implementation uses incremental path insertion:
1. Split the graph into biconnected components (blocks).
2. Start each non-trivial block with one cycle.
3. Find the remaining bridges/fragments.
4. Compute the faces in which each bridge can be inserted.
5. Insert an alpha-path into an admissible face and split that face.
6. If a bridge has no admissible face, report non-planar.

Only Python's standard library is used.
"""

from collections import defaultdict, deque


def edge_key(u, v):
    """Return a consistent representation of an undirected edge."""
    return (u, v) if u <= v else (v, u)


def find_biconnected_components(vertices, adjacency):
    """Tarjan DFS: return edge-biconnected blocks (vertex sets)."""
    discovery = {}
    low = {}
    parent = {}
    edge_stack = []
    blocks = []
    time = 0

    def dfs(u):
        nonlocal time
        time += 1
        discovery[u] = low[u] = time
        child_count = 0

        for v in adjacency[u]:
            if v not in discovery:
                parent[v] = u
                child_count += 1
                edge_stack.append((u, v))
                dfs(v)
                low[u] = min(low[u], low[v])

                if low[v] >= discovery[u]:
                    block_edges = []
                    while edge_stack:
                        e = edge_stack.pop()
                        block_edges.append(e)
                        if e == (u, v):
                            break
                    block_vertices = set()
                    for a, b in block_edges:
                        block_vertices.add(a)
                        block_vertices.add(b)
                    if block_vertices:
                        blocks.append(block_vertices)

            elif parent.get(u) != v and discovery[v] < discovery[u]:
                low[u] = min(low[u], discovery[v])
                edge_stack.append((u, v))

    for vertex in vertices:
        if vertex not in discovery:
            dfs(vertex)
            if edge_stack:
                block_vertices = set()
                while edge_stack:
                    a, b = edge_stack.pop()
                    block_vertices.update((a, b))
                if block_vertices:
                    blocks.append(block_vertices)

    return blocks


def find_cycle(vertices, adjacency):
    """Find one simple cycle in a connected, non-trivial biconnected block."""
    visited = set()
    parent = {}

    def dfs(u, p):
        visited.add(u)
        parent[u] = p
        for v in adjacency[u]:
            if v == p:
                continue
            if v not in visited:
                result = dfs(v, u)
                if result:
                    return result
            else:
                # In an undirected DFS, an edge to an ancestor closes a cycle.
                path = [u]
                current = u
                while current != v and current is not None:
                    current = parent.get(current)
                    if current is not None:
                        path.append(current)
                if path[-1] == v and len(path) >= 3:
                    path.reverse()
                    return path
        return None

    for vertex in vertices:
        if vertex not in visited:
            result = dfs(vertex, None)
            if result:
                return result
    return None


def get_fragments(block_vertices, block_adjacency, embedded_vertices, used_edges):
    """
    Find DMP fragments relative to the currently embedded subgraph.

    A fragment is either:
      - a connected component of unembedded vertices plus its incident
        edges to embedded vertices; or
      - one unused edge joining two already embedded vertices (a chord).
    """
    unembedded = set(block_vertices) - embedded_vertices
    fragments = []

    # Components made of vertices not yet embedded.
    unseen = set(unembedded)
    while unseen:
        start = next(iter(unseen))
        component = set()
        queue = [start]
        unseen.remove(start)

        while queue:
            u = queue.pop()
            component.add(u)
            for v in block_adjacency[u]:
                if v in unseen:
                    unseen.remove(v)
                    queue.append(v)

        contacts = set()
        for u in component:
            for v in block_adjacency[u]:
                if v in embedded_vertices:
                    contacts.add(v)

        if contacts:
            fragments.append({
                "kind": "component",
                "vertices": component,
                "contacts": contacts,
            })

    # Chords between vertices already in the embedded subgraph.
    for u in embedded_vertices:
        for v in block_adjacency[u]:
            if v in embedded_vertices and edge_key(u, v) not in used_edges:
                if u < v:
                    fragments.append({
                        "kind": "chord",
                        "vertices": set(),
                        "contacts": {u, v},
                        "chord": (u, v),
                    })

    return fragments


def admissible_faces(fragment, faces):
    """Faces whose boundary contains every attachment/contact of a fragment."""
    contacts = fragment["contacts"]
    return [
        index for index, face in enumerate(faces)
        if contacts.issubset(set(face))
    ]


def find_alpha_path(fragment, adjacency, chosen_face):
    """
    Find a path inside a fragment between two contact vertices on the
    chosen face. Internal vertices must belong to the fragment.
    """
    if fragment["kind"] == "chord":
        return list(fragment["chord"])

    allowed_contacts = fragment["contacts"].intersection(chosen_face)
    if len(allowed_contacts) < 2:
        return None

    # Try contact pairs until a connecting path is found.
    contacts = list(allowed_contacts)
    component_vertices = fragment["vertices"]

    for start_index in range(len(contacts)):
        for end_index in range(start_index + 1, len(contacts)):
            start = contacts[start_index]
            target = contacts[end_index]
            queue = deque([start])
            previous = {start: None}

            while queue and target not in previous:
                u = queue.popleft()
                for v in adjacency[u]:
                    if v in previous:
                        continue
                    # A component-fragment path must enter its unembedded
                    # component immediately; an existing edge between two
                    # contacts belongs to a separate chord fragment.
                    if u == start:
                        allowed = v in component_vertices
                    else:
                        allowed = v in component_vertices or v == target
                    if allowed:
                        previous[v] = u
                        queue.append(v)

            if target in previous:
                path = []
                current = target
                while current is not None:
                    path.append(current)
                    current = previous[current]
                path.reverse()
                if len(path) >= 2:
                    return path

    return None


def split_face(face, path):
    """
    Insert path (u ... v) into a face boundary and return the two new
    face boundaries. The input face is a cyclic list of vertices.
    """
    u, v = path[0], path[-1]
    if u not in face or v not in face or u == v:
        raise ValueError("Path endpoints must be distinct vertices on the face.")

    i = face.index(u)
    j = face.index(v)
    n = len(face)

    forward = []
    k = i
    while True:
        forward.append(face[k])
        if k == j:
            break
        k = (k + 1) % n

    backward = []
    k = j
    while True:
        backward.append(face[k])
        if k == i:
            break
        k = (k + 1) % n

    internal = path[1:-1]
    first_face = forward + list(reversed(internal))
    second_face = backward + internal
    return first_face, second_face


def test_block_dmp(vertices, adjacency, verbose=False):
    """Run DMP on one biconnected block."""
    vertices = set(vertices)

    if len(vertices) <= 2:
        return True, [], []

    cycle = find_cycle(vertices, adjacency)
    if not cycle:
        # A biconnected block with at least three vertices should contain a cycle.
        return False, [], ["Could not find an initial cycle."]

    # A cycle has two faces: its inside and outside.
    faces = [cycle[:], list(reversed(cycle))]
    embedded_vertices = set(cycle)
    used_edges = {
        edge_key(cycle[i], cycle[(i + 1) % len(cycle)])
        for i in range(len(cycle))
    }
    steps = []

    while True:
        fragments = get_fragments(
            vertices, adjacency, embedded_vertices, used_edges
        )

        if not fragments:
            return True, faces, steps

        # Calculate the admissible faces for every remaining fragment.
        candidates = []
        for fragment in fragments:
            possible_faces = admissible_faces(fragment, faces)
            candidates.append((len(possible_faces), fragment, possible_faces))

        # DMP prioritizes a fragment with the fewest admissible faces.
        candidates.sort(key=lambda item: item[0])
        count, fragment, possible_faces = candidates[0]

        if count == 0:
            description = {
                "kind": fragment["kind"],
                "contacts": sorted(fragment["contacts"]),
                "admissible_faces": 0,
            }
            steps.append(description)
            return False, faces, steps

        # If there is a forced face, use it. Otherwise choose the first
        # admissible face; the standard DMP procedure permits a choice here.
        face_index = possible_faces[0]
        chosen_face = faces[face_index]
        path = find_alpha_path(fragment, adjacency, chosen_face)

        if path is None:
            steps.append({
                "kind": fragment["kind"],
                "contacts": sorted(fragment["contacts"]),
                "error": "Could not construct an alpha-path.",
            })
            return False, faces, steps

        # Add the alpha-path to the current embedding.
        new_faces = split_face(chosen_face, path)
        faces.pop(face_index)
        faces.extend(new_faces)

        for i in range(len(path) - 1):
            used_edges.add(edge_key(path[i], path[i + 1]))

        embedded_vertices.update(path)

        steps.append({
            "kind": fragment["kind"],
            "path": path,
            "face_before_insertion": face_index,
            "faces_after_insertion": len(faces),
        })


def is_planar_dmp(vertices, edges, verbose=False):
    """
    Test an undirected simple graph using the DMP path-insertion method.

    Parameters
    ----------
    vertices : iterable
        Vertex labels (integers or strings).
    edges : iterable of pairs
        Undirected edges.
    verbose : bool
        If True, print progress information.

    Returns
    -------
    dict
        Contains 'is_planar', 'steps', and 'faces' information.
    """
    vertices = list(vertices)
    adjacency = {v: set() for v in vertices}

    for u, v in edges:
        if u not in adjacency or v not in adjacency:
            raise ValueError(f"Edge ({u}, {v}) uses an undeclared vertex.")
        if u == v:
            raise ValueError("Self-loops are not supported in this simple-graph implementation.")
        adjacency[u].add(v)
        adjacency[v].add(u)

    # Tarjan decomposition allows articulation points and disconnected graphs.
    blocks = find_biconnected_components(vertices, adjacency)

    all_steps = []
    all_faces = []
    for block_number, block in enumerate(blocks, start=1):
        block_adjacency = {
            v: adjacency[v].intersection(block) for v in block
        }

        planar, faces, steps = test_block_dmp(block, block_adjacency, verbose)
        all_steps.append({
            "block": block_number,
            "vertices": sorted(block, key=str),
            "is_planar": planar,
            "steps": steps,
        })
        all_faces.append({
            "block": block_number,
            "faces": faces if planar else [],
        })

        if not planar:
            return {
                "is_planar": False,
                "blocks": all_steps,
                "faces": all_faces,
            }

    return {
        "is_planar": True,
        "blocks": all_steps,
        "faces": all_faces,
    }
