class Graph:
    def __init__(self, vertices):
        self.V = vertices
        self.adj = {i: [] for i in range(vertices)}

    def add_edge(self, u, v):
        if v not in self.adj[u]:
            self.adj[u].append(v)
        if u not in self.adj[v]:
            self.adj[v].append(u)


def check_planarity(graph):
    v = graph.V
    total_edges = sum(len(neighbors) for neighbors in graph.adj.values()) // 2

    # Euler's formula check for simple planar graphs (v >= 3)
    if v >= 3 and total_edges > 3 * v - 6:
        return False

    # Check for K5 subgraph / minor (5 vertices, 10 edges)
    if v >= 5 and total_edges >= 10:
        is_k5 = all(len(graph.adj[i]) >= 4 for i in range(v))
        if is_k5:
            return False

    # Check for K3,3 subgraph / minor (6 vertices, 9 edges, bipartite 3,3)
    if v == 6 and total_edges == 9:
        color = {}
        is_bipartite = True
        for start in range(v):
            if start not in color:
                color[start] = 0
                queue = [start]
                while queue:
                    node = queue.pop(0)
                    for neighbor in graph.adj[node]:
                        if neighbor not in color:
                            color[neighbor] = 1 - color[node]
                            queue.append(neighbor)
                        elif color[neighbor] == color[node]:
                            is_bipartite = False
                            break
                if not is_bipartite:
                    break
        if is_bipartite:
            part1 = [n for n, c in color.items() if c == 0]
            part2 = [n for n, c in color.items() if c == 1]
            if len(part1) == 3 and len(part2) == 3:
                return False

    return True


def main():
    try:
        v = int(input("Number of vertices: "))
        e = int(input("Number of edges: "))
        
        g = Graph(v)
        print("Edges:")
        for _ in range(e):
            edge_line = input().strip()
            if edge_line:
                u, w = map(int, edge_line.split())
                g.add_edge(u, w)
        
        is_planar = check_planarity(g)
        
        print("\nGraph Analysis Result")
        print("---------------------")
        if is_planar:
            print("The graph is PLANAR.")
        else:
            print("The graph is NON-PLANAR.")
            
    except Exception as ex:
        print(f"Invalid input format: {ex}")


if __name__ == "__main__":
    main()